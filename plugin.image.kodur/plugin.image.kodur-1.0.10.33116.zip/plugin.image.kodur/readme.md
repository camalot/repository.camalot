
# ![](https://github.com/camalot/kodur/raw/develop/icon.png) Kodur

---

### How to install

 - Coming Soon!

----

![](https://github.com/camalot/kodur/raw/develop/.github/kodur-home.png)  
![](https://github.com/camalot/kodur/raw/develop/.github/kodur-gallery-browse.png)  
![](https://github.com/camalot/kodur/raw/develop/.github/kodur-reddit-home.png)  
![](https://github.com/camalot/kodur/raw/develop/.github/kodur-settings.png)
