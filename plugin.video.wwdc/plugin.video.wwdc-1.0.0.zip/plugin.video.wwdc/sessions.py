# -*- coding: utf-8 -*-
import json
import os
import os.path
import re
import urllib2

class Session:
    def __init__(self, session):
        self.name = session['title']
        self.description = session['description']
        self.sessionID = session['id']
        self.track = session['track']
        self.url = session['download_hd']
        self.fanart = session['images']['shelf']
        self.duration = session['duration']
        date = str(session['date'])
        if date is not None:
            self.year = date.split('-', 1)[0]
        self.title = '['+ self.year +'/'+ self.track +'] '+ self.name

    def getInfo(self):
        return {
            'duration': self.duration,
            'plot': self.description,
            'title': self.title,
            'year': self.year,
        }

class Sessions:
    def __init__(self, url, dataPath):
        self.url = url
        self.cacheFile = os.path.join(dataPath, 'sessions.json')

    def clearCache(self):
        if os.path.isfile(self.cacheFile):
            os.remove(self.cacheFile)

    def years(self):
        self.sessions = self._loadSessions()
        years = []
        for session in self.sessions:
            if session.year in years or session.year == 'None':
                continue
            years.append(session.year)
        return years

    def list(self, year):
        self.sessions = self._loadSessions()
        result = []
        for session in self.sessions:
            if session.year == year:
                result.append(session)
        return result

    def find(self, sessionID):
        self.sessions = self._loadSessions()
        for session in self.sessions:
            if session.sessionID == sessionID:
                return session

    def search(self, keyword):
        self.sessions = self._loadSessions()
        result = []
        for session in self.sessions:
            for token in session.title.split():
                if keyword.lower() in token.lower():
                    result.append(session)
        return result

    def _loadSessions(self):
        sessions = []
        try:
            with open(self.cacheFile) as data:
                data = json.load(data)
        except:
            data = self._fetchData()
        if data is not None:
            for session in data['sessions']:
                sessions.append(Session(session))
        return sessions

    def _fetchData(self):
        request = urllib2.Request(self.url)
        try:
            response = urllib2.urlopen(request)
            result = response.read()
            response.close()
            self._writeCache(result)
            return json.loads(result)
        except:
            return None

    def _writeCache(self, data):
        cache = open(self.cacheFile, 'w')
        cache.write(data)
        cache.close
