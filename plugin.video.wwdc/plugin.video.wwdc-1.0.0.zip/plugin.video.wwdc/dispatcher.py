# -*- coding: utf-8 -*-
from operator import itemgetter
from sessions import *
from urlparse import parse_qs, urlparse
import errno
import sys
import urllib
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

class Dispatcher:
    def __init__(self, handle):
        self.handle = handle
        self.baseUrl = 'plugin://' + xbmcaddon.Addon().getAddonInfo('id')
        self.basePath = xbmcaddon.Addon().getAddonInfo('path')
        self.dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        self.sessions = Sessions(xbmcaddon.Addon().getSetting('sessionsURL'), self.dataPath)
        try:
            os.makedirs(self.dataPath)
        except OSError as exc:
            if exc.errno == errno.EEXIST and os.path.isdir(self.dataPath):
                pass
            else:
                raise

    def dispatch(self, url):
        xbmcplugin.setContent(self.handle, 'episodes')
        params = self.params(url)
        action = ''.join(['action', params.pop('action', 'Years')])
        xbmc.log('Dispatching action: '+ action +' params: '+ str(params))
        if hasattr(self, action):
            getattr(self, action)(params)
        else:
            xbmc.log('Action not supported: '+ action)

    def listItem(self, session):
        url = self.urlFor('Play', {'sessionID': session.sessionID})
        item = xbmcgui.ListItem(session.title, path=url, iconImage=session.fanart, thumbnailImage=session.fanart)
        item.setInfo('video', session.getInfo())
        item.setProperty('IsPlayable', 'true')
        item.addContextMenuItems([('Toggle watched', 'Action(ToggleWatched)')])
        return (url, item, False)

    def params(self, url):
        params = parse_qs(urlparse(url).query)
        for key in params:
            params[key] = params[key][0]
        return params

    def urlFor(self, action, params):
        params['action'] = action
        return self.baseUrl +'/?'+ urllib.urlencode(params)

    # Actions

    def actionClearCache(self, params):
        self.sessions.clearCache()
        xbmc.executebuiltin('Notification(WWDC,Cache cleared...,2000)')

    def actionPlay(self, params):
        sessionID = params.pop('sessionID')
        session = self.sessions.find(sessionID)
        item = xbmcgui.ListItem(session.title, path=session.url, iconImage=session.fanart, thumbnailImage=session.fanart)
        xbmcplugin.setResolvedUrl(handle=self.handle, succeeded=True, listitem=item)

    def actionSearch(self, params):
        kb = xbmc.Keyboard('', 'Search', False)
        kb.doModal()
        if kb.isConfirmed():
            sessions = []
            for session in sorted(self.sessions.search(kb.getText()), key=lambda x: x.title, reverse=False):
                sessions.append(self.listItem(session))
            xbmcplugin.addDirectoryItems(self.handle, sessions, len(sessions))
            xbmcplugin.endOfDirectory(self.handle)

    def actionYears(self, params):
        if len(self.sessions.years()) == 0:
            xbmc.executebuiltin('Notification(WWDC,Could not load WWDC sessions...,4000)')
            return
        for year in sorted(self.sessions.years()):
            item = xbmcgui.ListItem(year, iconImage='DefaultFolder.png', thumbnailImage='DefaultFolder.png')
            item.setInfo(type='video', infoLabels={'title': year})
            url = self.urlFor('Year', {'year': year})
            xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=item, isFolder=True)
        item = xbmcgui.ListItem('Search', iconImage='DefaultFolder.png', thumbnailImage='DefaultFolder.png')
        item.setInfo(type='video', infoLabels={'title': 'Search'})
        xbmcplugin.addDirectoryItem(handle=self.handle, url=self.urlFor('Search', {}), listitem=item, isFolder=True)
        xbmcplugin.endOfDirectory(self.handle)

    def actionYear(self, params):
        year = params.pop('year', '2016')
        if len(self.sessions.list(year)) == 0:
            xbmc.executebuiltin('Notification(WWDC,Could not load WWDC sessions...,4000)')
            return
        sessions = []
        for session in sorted(self.sessions.list(year), key=lambda x: x.title, reverse=False):
            sessions.append(self.listItem(session))
        xbmcplugin.addDirectoryItems(self.handle, sessions, len(sessions))
        xbmcplugin.endOfDirectory(self.handle)
