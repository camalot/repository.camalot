# -*- coding: utf-8 -*-
from dispatcher import *
import sys

Dispatcher(int(sys.argv[1])).dispatch(sys.argv[2])
