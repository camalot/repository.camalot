# Microsoft Virtual Academy Addon for Kodi

A kodi addon for watching videos on Microsoft Virtual Academy

[![Home][5]][1]

[![Topics][6]][2]

[![Search][7]][3]

[![Course][8]][4]

[1]: http://i.imgur.com/a4CXD89.png
[2]: http://i.imgur.com/R13pdTQ.png
[3]: http://i.imgur.com/zJdU2g6.png
[4]: http://i.imgur.com/QefnuBn.png
[5]: http://i.imgur.com/a4CXD89l.png
[6]: http://i.imgur.com/R13pdTQl.png
[7]: http://i.imgur.com/zJdU2g6l.png
[8]: http://i.imgur.com/QefnuBnl.png