
import control


class Main:
    def __init__(self):
        control.openSettings()
        return