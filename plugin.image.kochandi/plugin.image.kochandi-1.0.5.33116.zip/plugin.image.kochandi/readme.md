
# ![](https://github.com/camalot/kochandi/raw/develop/icon.png) KoChanDi (co-chan-dee)


This is just something I threw together because I was bored and found the [4Chan Api](https://github.com/4chan/4chan-API).

---

### How to install

 - Coming Soon!

----

![](https://github.com/camalot/kochandi/raw/develop/.github/kochandi-settings.png)

![](https://github.com/camalot/kochandi/raw/develop/.github/kochandi-boards.png)

When you enable NSFW boards they are indicated in red.

![](https://github.com/camalot/kochandi/raw/develop/.github/kochandi-boards-adult.png)
